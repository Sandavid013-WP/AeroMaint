AeroMaint - GA6-220501096-AA4-EV03
Diseño front-end desarrollado con HTML, CSS y JavaScript.

Para probarlo: abrir index.html en un navegador.

Incluye: dashboard, menú de navegación, gestión visual de aeronaves, búsqueda y filtro, formulario modal, validación básica e interacción JavaScript.

El diseño aplica la propuesta visual anterior de AeroMaint: interfaz oscura, azul como color principal, estados diferenciados y navegación lateral.
